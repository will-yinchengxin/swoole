<?php
/**
 * Create By: Will Yin
 * Date: 2020/7/7
 * Time: 11:24
 **/
namespace App\Http\Controller;
//用于测试的控制器
Class IndexController{

    public function test($a = null)
    {
        return "\n this is IndexController \n";
  }
}