<?php
/**
 * Create By: Will Yin
 * Date: 2020/7/8
 * Time: 10:15
 **/
namespace SwooleWork;
Class Index{
    public function test()
    {
        echo "this is test index()\n\r";
    }
}