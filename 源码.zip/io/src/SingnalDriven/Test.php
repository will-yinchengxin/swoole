<?php
/**
 * Create By: Will Yin
 * Date: 2020/6/29
 * Time: 15:38
 **/
namespace Willyin\Io\SingnalDriven;
class Test{
    public function index() {
        echo 1;
        debug('oo oo11');
    }
}