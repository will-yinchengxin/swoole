<?php
/**
 * Create By: Will Yin
 * Date: 2020/7/1
 * Time: 15:54
 **/

namespace Willyin\Io;
Class Test{
    public function index()
    {
        echo "this is will test inotify";
    }
}
